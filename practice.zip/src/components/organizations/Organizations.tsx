import { Box, Flex, Grid, Image, Heading, Link, Text } from '@chakra-ui/react';
import { useState, useEffect } from "react";

// Example component replicating the structure
export const Organizations = () => {
  const [year, setYear] = useState(new Date().getFullYear());
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    // Fetch countries (mock API for demo purposes)
    loadJurisdictions(setCountries);
  }, []);

  // Function to fetch countries from an API
  const loadJurisdictions = async (setCountries) => {
    //const data = await fetch("/api/brand/v1/countries/betpawa");
    const countriesData = [
        {
          "id": 1,
          "name": "Bet Booth",
          "active": true,
          "fantasy": false,
          "denominationSymbol": "$",
          "primaryColor": "#007cff",
          "secondaryColor": "#00458f",
          "tertiaryColor": "#dfe218",
          "logoUrl": "https://betbooth-public.s3.ca-central-1.amazonaws.com/org-branding/bb_logo_blue_white_text.png",
          "darkLogoUrl": "https://betbooth-public.s3.ca-central-1.amazonaws.com/org-branding/bet-booth-blue-horizontal-logo.png",
          "badgeUrl": "https://betbooth-public.s3.ca-central-1.amazonaws.com/org-branding/bb_badge_blue.png",
          "slug": "bet-booth-blue",
          "oddsDisplay": "American",
          "layout": "American",
          "taxRate": 0.1,
          "language": "en",
          "flagIcon": null,
          "domain": null
        }
      ];
    setCountries(countriesData);
  };

  return (
    <Box>
      {/* Intro Section */}
      <Flex bg="gray.700" p={8} justify="center" align="center" direction="column">
        <Image src="https://static.betpawa.com/img/landing/logo_color.png" alt="betPawa Logo" mb={4} />
        <Text color="white" fontSize="lg">Bet small win BIG</Text>
      </Flex>

      {/* Country Selection Grid */}
      <Box p={8}>
        <Heading as="h3" mb={6} textAlign="center">Select your country</Heading>
        <Grid templateColumns="repeat(auto-fill, minmax(150px, 1fr))" gap={6}>
          {countries.map((country) => (
            <Link href={`https://www.${country.domain}`} key={country.name}>
              <Box
                p={4}
                border="1px solid"
                borderColor="gray.300"
                borderRadius="md"
                _hover={{ bg: "gray.50", boxShadow: "md" }}
                textAlign="center"
              >
                <Image src={`${logoUrl}`} alt={country.name} mb={2} />
                <Heading as="h4" size="sm">{country.name}</Heading>
              </Box>
            </Link>
          ))}
        </Grid>
      </Box>

      {/* Footer */}
      <Flex bg="gray.900" p={4} justify="center" align="center" direction="column" color="white">
        <Image src="./images/logo_monochrome.png" alt="betPawa Monochrome Logo" mb={2} />
        <Text>© betPawa {year}. All Rights Reserved</Text>
      </Flex>
    </Box>
  );
};